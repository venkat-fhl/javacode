public class Operations {
    public static void main(String[] args) {
        // Perform the given operations and store the results
        int resultA = -5 + 8 * 6;
        int resultB = (55 + 9) % 9;
        int resultC = 20 + -3 * 5 / 8;
        int resultD = 5 + 15 / 3 * 2 - 8 % 3;

        // Print the results
        System.out.println(resultA);  // Output: 43
        System.out.println(resultB);  // Output: 1
        System.out.println(resultC);  // Output: 19
        System.out.println(resultD);  // Output: 13
    }
}