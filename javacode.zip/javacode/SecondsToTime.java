import java.util.Scanner;

public class SecondsToTime {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Input the total seconds
            System.out.print("Input seconds: ");
            int totalSeconds = scanner.nextInt();

            // Calculate hours, minutes, and seconds
            int hours = totalSeconds / 3600;
            int remainingSeconds = totalSeconds % 3600;
            int minutes = remainingSeconds / 60;
            int seconds = remainingSeconds % 60;

            // Output the result in the format HH:MM:SS
            System.out.printf("%02d:%02d:%02d\n", hours, minutes, seconds);
        }
    }
}