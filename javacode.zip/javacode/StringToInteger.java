import java.util.Scanner;

public class StringToInteger {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Input a number as a string
            System.out.print("Input a number (string): ");
            String input = scanner.nextLine();

            // Convert the string to an integer
            int number = Integer.parseInt(input);

            // Output the integer value
            System.out.println("The integer value is: " + number);
        } catch (NumberFormatException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}