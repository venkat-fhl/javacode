public class DestructorExample {
    public void finalize() {
        System.out.println("Object is being garbage collected");
        // Add your cleanup code here
    }

    public static void main(String[] args) {
        DestructorExample obj = new DestructorExample();
        obj = null; // Make the object eligible for garbage collection
        System.gc(); // Request the garbage collector to run
    }
}