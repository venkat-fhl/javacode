public class Student {
    private int rollNo;
    private String name;

    // Constructor
    public Student(int rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }

    // Method to print student details
    public void printDetails() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
    }

    public static void main(String[] args) {
        // Create a new Student object with rollNo and name
        Student student = new Student(123, "John Doe");

        // Call the printDetails method
        student.printDetails();
    }
}