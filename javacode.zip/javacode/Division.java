public class Division {
    private double num1;
    private double num2;
    private double result;

    // Constructor to initialize numbers
    public Division(double num1, double num2) {
        this.num1 = num1;
        this.num2 = num2;
        this.result = divide();
    }

    // Method to perform division
    public double divide() {
        if (num2 == 0) {
            throw new ArithmeticException("Cannot divide by zero!");
        }
        return num1 / num2;
    }

    // Method to print the result
    public void printResult() {
        System.out.println("The result of dividing " + num1 + " by " + num2 + " is: " + result);
    }

    public static void main(String[] args) {
        Division division = new Division(10.0, 2.0);
        division.printResult();
    }
}