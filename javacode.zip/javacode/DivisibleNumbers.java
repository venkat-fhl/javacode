
public class DivisibleNumbers {
    public static void main(String[] args) {
        System.out.println("Numbers divisible by 3:");
        printDivisibleBy(3);

        System.out.println("\nNumbers divisible by 5:");
        printDivisibleBy(5);

        System.out.println("\nNumbers divisible by both 3 and 5:");
        printDivisibleByBoth(3, 5);
    }

    /**
     * Prints numbers between 1 and 100 that are divisible by the given number.
     * 
     * @param divisor the number to check for divisibility
     */
    public static void printDivisibleBy(int divisor) {
        for (int i = 1; i <= 100; i++) {
            if (i % divisor == 0) {
                System.out.print(i + " ");
            }
        }
    }

    /**
     * Prints numbers between 1 and 100 that are divisible by both given numbers.
     * 
     * @param divisor1 the first number to check for divisibility
     * @param divisor2 the second number to check for divisibility
     */
    public static void printDivisibleByBoth(int divisor1, int divisor2) {
        for (int i = 1; i <= 100; i++) {
            if (i % divisor1 == 0 && i % divisor2 == 0) {
                System.out.print(i + " ");
            }
        }
    }
}