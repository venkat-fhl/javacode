import java.util.Scanner;

public class PenultimateWord {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter a sentence: ");
            String sentence = scanner.nextLine();

            String[] words = sentence.split(" ");
            int numWords = words.length;

            if (numWords < 2) {
                System.out.println("The sentence must have at least two words.");
            } else {
                String penultimateWord = words[numWords - 2];
                System.out.println("The penultimate word is: " + penultimateWord);
            }
        }
    }
}